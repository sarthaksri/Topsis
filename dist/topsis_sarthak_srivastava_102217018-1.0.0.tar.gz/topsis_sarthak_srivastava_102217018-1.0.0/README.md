# Topsis Rank Calculation
It takes an integer as an input and prints it square.

## Installation
```pip install 102217018-topsis```

## How to use it?
Open terminal and type square and then input the integer

## License

© 2025 Sarthak Srivastava

This repository is licensed under the MIT license. See LICENSE for details.